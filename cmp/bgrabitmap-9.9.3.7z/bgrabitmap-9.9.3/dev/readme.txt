List of directories:
- makedoc: contains a program to make documentation from source code
- colorspace: contains a program to generate code for colorspaces

